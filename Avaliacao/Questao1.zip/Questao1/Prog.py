"""Movimentacao e colisao da bola com as extremidades da tela."""

from Bola import bola
import pygame

red = (255, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
darkBlue = (0, 0, 128)
white = (255, 255, 255)
black = (0, 0, 0)
pink = (255, 200, 200)


def criabola(center, radius, color):
    """Cria um objeto do tipo bola."""
    return bola(center, radius, color)


def movebola(direction):
    """Move a bola."""
    global bola
    if bola.x + 5 <= 400 - bola.radius and direction == 0:
        bola.x += 5
        return 0
    if bola.x + 5 >= 400 - bola.radius and direction == 0:
        bola.x = 400 - bola.radius
        bola.color = red
        return 1

    if bola.x - 5 >= 0 + bola.radius and direction == 1:
        bola.x -= 5
        return 1
    if bola.x - 5 <= 0 + bola.radius and direction == 1:
        bola.x = 0 + bola.radius
        bola.color = blue
        return 0


bola = criabola([200, 200], 50, white)


def main():
    """Metodo main."""
    pygame.init()
    screen = pygame.display.set_mode((400, 400))
    rodando = True
    clock = pygame.time.Clock()
    print(bola.center)
    print(bola.x)
    print(bola.y)
    direction = 0
    while rodando:
        clock.tick(60)
        pygame.draw.rect(screen, black, [0, 0, 400, 400],)
        direction = movebola(direction)
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    # print("ESC")
                    rodando = False
        print(bola.center)
        pygame.draw.circle(screen, bola.color, [bola.x, bola.y], bola.radius, )
        pygame.display.flip()


main()
